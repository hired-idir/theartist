<?php

namespace AppBundle\Controller;
use Symfony\Component\Validator\Constraints\Email as EmailConstraint;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Session\Session;
use Symfony\Component\Filesystem\Filesystem;
use AppBundle\Entity\Member;
use AppBundle\Entity\Partage;
use AppBundle\Entity\Jaimes;
use AppBundle\Entity\Abonnement;
use AppBundle\Entity\Commentaire;

use AppBundle\Repository\abonnementRepository;



use Symfony\Component\HttpFoundation\Response;

class DefaultController extends Controller
{
    /**
     * @Route("/", name="homepage")
     */
    public function indexAction(Request $request)
    {
        $conges=$this->getDoctrine()->getRepository('AppBundle:Partage') ->findAll();


/*
  $suivre= $this->getDoctrine()->getRepository('AppBundle:Abonnement') ->findT(array(
            'member'=> 	$this->get('session')->get('id')
,           

            
        ));*/
        
        
        $statement='';
        if($this->get('session')->has('id')){
         $em = $this->getDoctrine()->getManager();
        $query = $em->createQuery("SELECT c.pseudo,c.img FROM AppBundle:Member c WHERE c.id not in (SELECT r.member1 FROM AppBundle:Abonnement r WHERE r.member=".$this->get('session')->get('id')." ) AND c.pseudo!='".$this->get('session')->get('pseudo')."'");
        $statement = $query->getResult();
		}
        // replace this example code with whatever you need
        //$this->get('session')->remove('id');
      //  $this->get('session')->invalidate(1);
      

       	return $this->render('default/index.html.twig',array( 'resultat' => $conges , 'sug'=>$statement));

    }
    
    
    
      public function rechAction(Request $request)
    {
        // replace this example code with whatever you need
        //$this->get('session')->remove('id');
      //  $this->get('session')->invalidate(1);
              $this->get('session')->invalidate(1);
   		//	$m= https://api.themoviedb.org/3/search/movie?api_key=0fedfd61181ccdf2e0ae52c289826a6e&language=en-US&query="+$request->request->get('rech')+"&page=1&include_adult=false
	          $this->get('session')->set('recherche',$request->request->$m );

        return $this->render('default/index.html.twig', [
            'base_dir' => realpath($this->getParameter('kernel.root_dir').'/..'),
        ]);
    }
       public function decoAction(Request $request)
    {
        // replace this example code with whatever you need
        //$this->get('session')->remove('id');
        $this->get('session')->invalidate(1);
        return $this->render('default/index.html.twig', [
            'base_dir' => realpath($this->getParameter('kernel.root_dir').'/..'),
        ]);
    }
  
    //////////////////////////////////////////////////////////
  
          public function authAction(Request $request)
    {
    	$mdp= $this->getDoctrine()->getRepository('AppBundle:Member') ->findOneBy(array(
            'pseudo'   => $request->request->get('id'),
            'mdp' => $request->request->get('mdp')
        ));
        
        // replace this example code with whatever you need
        if(!$mdp){
 	return $this->render('default/index.html.twig',array( 'messe' => "informations incorrectes "));

	    }else {
	 //  $this->get('session')->start();
	          $this->get('session')->set('pseudo',$request->request->get('id') );
	
			   $this->get('session')->set('id',$mdp->getId() );
			   $this->get('session')->set('ab',$mdp->getAbonnes() );
		 

	    	return $this->redirectToRoute('home');
	    }
    
    }
    
    
           public function errorAction(Request $request)
    {
    
     return $this->render('default/error.html', [
            'base_dir' => realpath($this->getParameter('kernel.root_dir').'/..'),]);
    
    
    }
    
    
            public function insertAction(Request $request)
    {
    
    	if($request->request->get('mdp')!=$request->request->get('mdpc') ){
    				return $this->render('default/index.html.twig',array( 'messe' => "mots de passe non identiques"));

    	}
    	$mdp= $this->getDoctrine()->getRepository('AppBundle:Member') ->findOneBy(array(
            'pseudo'   => $request->request->get('pseudo')  ,
            'mail'  => $request->request->get('mail')         
        ));
        
        
    $email = $request->request->get('mail')  ;
    // ...

    $emailConstraint = new EmailConstraint();
    $emailConstraint->message = 'Your customized error message';

  
        // replace this example code with whatever you need
        if(!$mdp){
        
                $em = $this->getDoctrine()->getManager();

 				$question = new Member();
       			 $question->setPseudo($request->request->get('pseudo'));
       	 		$question->setMdp($request->request->get('mdp'));
       			 $question->setTel($request->request->get('tel'));
        		 $question->setImg($request->request->get('image'));
        
       
		  // $advert est une instance de Advert
		
		$question->setMail($request->request->get('mail'));
		
		
      	 	$em->persist($question);
       	 $em->flush();
	    	return $this->render('default/index.html.twig',array( 'messe' => "Enregistré avec succes "));

	    }else {
	 //  $this->get('session')->start();
	          

			return $this->render('default/index.html.twig',array( 'messe' => "erreur d'enregistrement"));

    
   		 }
    
    ////////////////////////////////////////////////////////////////////////////////
}
 public function partageAction(Request $request)
    {
    
    	
        
        // replace this example code with whatever you need
      
        
                $em = $this->getDoctrine()->getManager();

 			$question = new Partage();
       		 $question->setPseudo($this->get('session')->get('pseudo'));
       	 $question->setText($request->request->get('text'));
       	 $question->setDate(new \DateTime());
        
       	 $question->setJaime(0);
        
		  // $advert est une instance de Advert
		
		
		
      	 	$em->persist($question);
       	 $em->flush();
	    	return $this->redirectToRoute('home',array( 'messe' => "Enregistré avec succes "));

	 
    ////////////////////////////////////////////////////////////////////////////////
}

public function commentAction($id,$text)
    {
    
    	
        
        // replace this example code with whatever you need
      

                $em = $this->getDoctrine()->getManager();

 			$question = new Commentaire();
       		 $question->setPseudo($this->get('session')->get('pseudo'));
       	 $question->setText($text);
       	 $question->setPartage($id);
       	 
       	 $question->setDate(new \DateTime());
        
        
		  // $advert est une instance de Advert
		
		
		
      	 	$em->persist($question);
       	 $em->flush();
       	 
       	 
            
            	
            	
            	  $tout = $em->createQuery(
       			 'SELECT c
        			FROM AppBundle:Commentaire c where c.partage='.$id.''
    				)	;
       	 
				 $categorias = $tout->getArrayResult();
	
		     	    $response = new Response(json_encode($categorias));
  				    $response->headers->set('Content-Type', 'application/json');

   				    return $response;

	 
    ////////////////////////////////////////////////////////////////////////////////
}


public function commentsAction($id)
    {
    
    	
        
        // replace this example code with whatever you need
      

       	 
            
            	                $em = $this->getDoctrine()->getManager();

            	
            	  $tout = $em->createQuery(
       			 'SELECT c
        			FROM AppBundle:Commentaire c where c.partage='.$id.''
    				)	;
       	 
				 $categorias = $tout->getArrayResult();
	
		     	    $response = new Response(json_encode($categorias));
  				    $response->headers->set('Content-Type', 'application/json');

   				    return $response;

	 
    ////////////////////////////////////////////////////////////////////////////////
}


 public function jaimeAction($id)
    {
    
    	
    	$jaime= $question= $this->getDoctrine()->getRepository('AppBundle:Jaimes') ->findOneBy(array(
            'member'=> 	$this->get('session')->get('id')
            
            ,'partage'   => $id
            
        ));
        
        if(!$jaime){
        // replace this example code with whatever you need
      
        $question= $this->getDoctrine()->getRepository('AppBundle:Partage') ->findOneBy(array(
            'id'   => $id
            
        ));
        
                $em = $this->getDoctrine()->getManager();
		
		if($question){
			$b=$question->getJaime();
       		 $question->setJaime($b+1);
       
		  // $advert est une instance de Advert
		
		
		
      	 	$em->persist($question);
       	 $em->flush();
       	 
       	 $j=new Jaimes();
       	 $j->setMember($this->get('session')->get('id'));
       	 $j->setPartage($id);
       	 
       	 	$em->persist($j);
       	 $em->flush();
//	    	return $this->redirectToRoute('home',array( 'messe' => "Enregistré avec succes "));
			return new Response($question->getJaime());
	 	}else
	 	return $this->redirectToRoute($id ,array( 'messe' => $id ));

		}
		else 	{		
		
		
		  $question= $this->getDoctrine()->getRepository('AppBundle:Partage') ->findOneBy(array(
            'id'   => $id
            
        ));
        
                $em = $this->getDoctrine()->getManager();
		
			$b=$question->getJaime();
       		 $question->setJaime($b-1);
       
		  // $advert est une instance de Advert
		
		
		
      	 	$em->persist($question);
       	 $em->flush();
       	 
       	 $jaime->setMember(0);
       	 $jaime->setPartage(0);
       	 
       	 	$em->persist($jaime);
       	 $em->flush();
		
		
		
		
		
		return new Response($question->getJaime());
		
		
		
		}

    ////////////////////////////////////////////////////////////////////////////////
}


 public function profilAction($pseudo)
    {
    
    	
        
        // replace this example code with whatever you need
      

        
        $question= $this->getDoctrine()->getRepository('AppBundle:Member') ->findOneBy(array(
            'pseudo'   => $pseudo
            
        ));
        
              $suivre= $this->getDoctrine()->getRepository('AppBundle:Abonnement') ->findOneBy(array(
            'member'=> 	$this->get('session')->get('id')
,           'member1'   => $question->getId()
            
        ));
        
        $res="S'abonner";
        if($suivre)
        $res="se désabonner";
                $question1= $this->getDoctrine()->getRepository('AppBundle:Partage') ->findBy(array(
            'pseudo'   => $pseudo
            
        ));
		
		if($question){
			    	return $this->render('default/in.html',array( 'rep' => $question,'resultat'=>$question1,'res'=>$res));


	 	}else
	 	return $this->redirectToRoute($id ,array( 'messe' => $pseudo ));

    ////////////////////////////////////////////////////////////////////////////////
}

 public function suivreAction($id)
    {
    
$suivre= $this->getDoctrine()->getRepository('AppBundle:Abonnement') ->findOneBy(array(
            'member'=> 	$this->get('session')->get('id')
, 'member1'   => $id
            
        ));
    
                    $em = $this->getDoctrine()->getManager();

    if(!$suivre){
    
	$ques= $this->getDoctrine()->getRepository('AppBundle:Member') ->findOneBy(array(
            'id'   => $id
            
        ));
        
		
		if($ques){
			$b=$ques->getAbonnes();
       		 $ques->setAbonnes($b+1);
       
      	 	$em->persist($ques);
       	 $em->flush();
	   
	   
	    $question= $this->getDoctrine()->getRepository('AppBundle:Member') ->findOneBy(array(
            'id'   => $id
            
        ));
                $question1= $this->getDoctrine()->getRepository('AppBundle:Partage') ->findBy(array(
            'pseudo'   => $question->getPseudo()
            
        ));
        
        
        $suite=new Abonnement();
        $suite->setMember($this->get('session')->get('id'));
        $suite->setMember1($id);
        
        
        	$em->persist($suite);
       	 $em->flush();
		
			    	return $this->redirectToRoute('profil',array( 'pseudo' => $question->getPseudo() ));

	 	}else
	 	return $this->redirectToRoute($id ,array( 'messe' => $id ));
	 	
	 }else {
	 
	 	$ques= $this->getDoctrine()->getRepository('AppBundle:Member') ->findOneBy(array(
            'id'   => $id
            
        ));
	 $b=$ques->getAbonnes();
       		 $ques->setAbonnes($b-1);
       
		  // $advert est une instance de Advert
		
		
		
      	 	$em->persist($ques);
       	 $em->flush();
	   
	   
	    $question= $this->getDoctrine()->getRepository('AppBundle:Member') ->findOneBy(array(
            'id'   => $id
            
        ));
                $question1= $this->getDoctrine()->getRepository('AppBundle:Partage') ->findBy(array(
            'pseudo'   => $question->getPseudo()
            
        ));
        
        
        $suivre->setMember(0);
        $suivre->setMember1(0);
        
        
        	$em->persist($suivre);
       	 $em->flush();
	 
	 
	 
	 
	 
	 return $this->redirectToRoute('profil',array( 'pseudo' => $question->getPseudo() ));
	 
	 }
}


 public function forgetAction(Request $request)
    {
    
    	
        
        // replace this example code with whatever you need
      

        
        $question= $this->getDoctrine()->getRepository('AppBundle:Member') ->findOneBy(array(
            'pseudo'   => $request->request->get('id'),'tel'=>$request->request->get('tel') , 'mail'=>$request->request->get('mail')
            
        ));
        
              
        
		if($question){
	 	return $this->redirectToRoute('home' ,array( 'mdp' => $question->getMdp()));

			    	return $this->render('default/index.html.twig',array( 'mdp' => $question));

	 	}else
	 	return $this->redirectToRoute('home' ,array( 'mdp' => 'erreur données'));

    ////////////////////////////////////////////////////////////////////////////////
}

}