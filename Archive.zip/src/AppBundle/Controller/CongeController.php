<?php

namespace AppBundle\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use AppBundle\Entity\salarie;
use AppBundle\Entity\conge;
use Symfony\Component\Validator\Constraints\Date; 
class  CongeController extends Controller
{
    /**
     * @Route("/", name="homepage")
     */
    public function indexAction(Request $request)
    {
        // replace this example code with whatever you need
        return $this->render('default/conge.html.twig', [
            'base_dir' => realpath($this->getParameter('kernel.root_dir').'/..'),
        ]);
    }
	 public function tableAction(Request $request)
    {
        $this->get('session')->start();
        $b=$this->get('session')->get('id');
    	$mdp= $this->getDoctrine()->getRepository('AppBundle:conge') ->findBy(array('salarie'=>$b));
        $repository=$this->getDoctrine()->getRepository('AppBundle:salarie') ;
        $query = $repository->createQueryBuilder('p')
        ->where('p.superieurHierarchique= :id')
        ->setParameter('id',$b)
        ->getQuery();
        $salaries = $query->getResult();
        $conges=$this->getDoctrine()->getRepository('AppBundle:conge') ->findAll();
        return $this->render('default/conge.html.twig',array( 'vac' => $mdp,'salaries'=>$salaries,'conges'=>$conges,'cp'=>$this->get('session')->get('cp')));
    }
     public function reserverAction(Request $request)
    {    
        $this->get('session')->start();
        $b=$this->get('session')->get('id');
        $em = $this->getDoctrine()->getManager();
        $sal= $this->getDoctrine()->getRepository('AppBundle:salarie') ->findOneBy(array('id'=>$b));
        $date1=strtotime($request->request->get('debut'));
         $date2=strtotime($request->request->get('fin'));
        $nbj=($date2-$date1)/(3600*24);
        $cp=$this->get('session')->get('cp');
        $cp=$cp-$nbj;
         $this->get('session')->set('cp',$cp);
        $sal->setCp($cp);
        $vac = new conge();
        $vac->setDebut(new \DateTime($request->request->get('debut')));
        $vac->setFin(new \DateTime($request->request->get('fin')));
        $vac->setValide(false);
        $vac->setSalarie($sal);
        $em->persist($vac);
        $em->flush();
        return $this->tableAction($request);
    }
    public function validerAction(Request $request)
    {
        $cong= $this->getDoctrine()->getRepository('AppBundle:conge') ->findOneBy(array(
            'id'  =>$request->request->get('idc')
        ));
        $cong->setValide(!($cong->getValide()));
        $em = $this->getDoctrine()->getManager();
        $em->persist($cong);
        $em->flush();  
         
        return $this->tableAction($request);return $this->tableAction($request);
    }
     public function recrutement(Request $request)
    {
        $this->get('session')->start();
        $b=$this->get('session')->get('id');
        $mdp= $this->getDoctrine()->getRepository('AppBundle:postes') ->findBy(array('salarie'=>$b));
        $candidats=$this->getDoctrine()->getRepository('AppBundle:candidats') ->findAll();
        $repository=$this->getDoctrine()->getRepository('AppBundle:candidats') ;
        $salaries = $query->getResult();
        $conges=$this->getDoctrine()->getRepository('AppBundle:conge') ->findAll();
        return $this->render('default/recrutement.html.twig',array( 'postes' => $mdp,'candidats'=>$candidats));
    }
    }
   
