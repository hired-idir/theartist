<?php

namespace AppBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Abonnement
 *
 * @ORM\Table(name="abonnement")
 * @ORM\Entity
 */
class Abonnement
{
    /**
     * @var integer
     *
     * @ORM\Column(name="member", type="integer", nullable=false)
     */
    private $member;

    /**
     * @var integer
     *
     * @ORM\Column(name="member1", type="integer", nullable=false)
     */
    private $member1;

    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;



    /**
     * Set member
     *
     * @param integer $member
     *
     * @return Abonnement
     */
    public function setMember($member)
    {
        $this->member = $member;

        return $this;
    }

    /**
     * Get member
     *
     * @return integer
     */
    public function getMember()
    {
        return $this->member;
    }

    /**
     * Set member1
     *
     * @param integer $member1
     *
     * @return Abonnement
     */
    public function setMember1($member1)
    {
        $this->member1 = $member1;

        return $this;
    }

    /**
     * Get member1
     *
     * @return integer
     */
    public function getMember1()
    {
        return $this->member1;
    }

    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }
}
