<?php

namespace AppBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Member
 *
 * @ORM\Table(name="member")
 * @ORM\Entity
 */
class Member
{
    /**
     * @var string
     *
     * @ORM\Column(name="pseudo", type="string", length=40, nullable=false)
     */
    private $pseudo;

    /**
     * @var string
     *
     * @ORM\Column(name="mdp", type="string", length=40, nullable=false)
     */
    private $mdp;

    /**
     * @var string
     *
     * @ORM\Column(name="tel", type="string", length=40, nullable=false)
     */
    private $tel;

    /**
     * @var string
     *
     * @ORM\Column(name="mail", type="string", length=40, nullable=false)
     */
    private $mail;

    /**
     * @var integer
     *
     * @ORM\Column(name="abonnes", type="integer", nullable=false)
     */
    private $abonnes = '0';

    /**
     * @var integer
     *
     * @ORM\Column(name="publications", type="integer", nullable=false)
     */
    private $publications = '0';

    /**
     * @var string
     *
     * @ORM\Column(name="img", type="text", length=65535, nullable=false)
     */
    private $img;

    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;



    /**
     * Set pseudo
     *
     * @param string $pseudo
     *
     * @return Member
     */
    public function setPseudo($pseudo)
    {
        $this->pseudo = $pseudo;

        return $this;
    }

    /**
     * Get pseudo
     *
     * @return string
     */
    public function getPseudo()
    {
        return $this->pseudo;
    }

    /**
     * Set mdp
     *
     * @param string $mdp
     *
     * @return Member
     */
    public function setMdp($mdp)
    {
        $this->mdp = $mdp;

        return $this;
    }

    /**
     * Get mdp
     *
     * @return string
     */
    public function getMdp()
    {
        return $this->mdp;
    }

    /**
     * Set tel
     *
     * @param string $tel
     *
     * @return Member
     */
    public function setTel($tel)
    {
        $this->tel = $tel;

        return $this;
    }

    /**
     * Get tel
     *
     * @return string
     */
    public function getTel()
    {
        return $this->tel;
    }

    /**
     * Set mail
     *
     * @param string $mail
     *
     * @return Member
     */
    public function setMail($mail)
    {
        $this->mail = $mail;

        return $this;
    }

    /**
     * Get mail
     *
     * @return string
     */
    public function getMail()
    {
        return $this->mail;
    }

    /**
     * Set abonnes
     *
     * @param integer $abonnes
     *
     * @return Member
     */
    public function setAbonnes($abonnes)
    {
        $this->abonnes = $abonnes;

        return $this;
    }

    /**
     * Get abonnes
     *
     * @return integer
     */
    public function getAbonnes()
    {
        return $this->abonnes;
    }

    /**
     * Set publications
     *
     * @param integer $publications
     *
     * @return Member
     */
    public function setPublications($publications)
    {
        $this->publications = $publications;

        return $this;
    }

    /**
     * Get publications
     *
     * @return integer
     */
    public function getPublications()
    {
        return $this->publications;
    }

    /**
     * Set img
     *
     * @param string $img
     *
     * @return Member
     */
    public function setImg($img)
    {
        $this->img = $img;

        return $this;
    }

    /**
     * Get img
     *
     * @return string
     */
    public function getImg()
    {
        return $this->img;
    }

    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }
}
