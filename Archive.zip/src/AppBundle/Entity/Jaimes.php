<?php

namespace AppBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Jaimes
 *
 * @ORM\Table(name="jaimes")
 * @ORM\Entity
 */
class Jaimes
{
    /**
     * @var integer
     *
     * @ORM\Column(name="member", type="integer", nullable=false)
     */
    private $member;

    /**
     * @var integer
     *
     * @ORM\Column(name="partage", type="integer", nullable=false)
     */
    private $partage;

    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;



    /**
     * Set member
     *
     * @param integer $member
     *
     * @return Jaimes
     */
    public function setMember($member)
    {
        $this->member = $member;

        return $this;
    }

    /**
     * Get member
     *
     * @return integer
     */
    public function getMember()
    {
        return $this->member;
    }

    /**
     * Set partage
     *
     * @param integer $partage
     *
     * @return Jaimes
     */
    public function setPartage($partage)
    {
        $this->partage = $partage;

        return $this;
    }

    /**
     * Get partage
     *
     * @return integer
     */
    public function getPartage()
    {
        return $this->partage;
    }

    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }
}
